<b><#selectbg_g>Terms of Use</#></b>

DebloatEx and hasenbolle are not responsible for any possible damage done to your device as a result of flashing.
I will not take any responsibility for bricked phones or lost data.

If you are not willing to agree with these conditions, don't continue and abort the installation process.